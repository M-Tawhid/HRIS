﻿using HRIS_R62.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;

namespace HRIS_R62.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AttendanceRecordsController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public AttendanceRecordsController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        private SqlConnection GetConnection()
        {
            return new SqlConnection(_configuration.GetConnectionString("appCon"));
        }

        // GET All
        [HttpGet("getall")]
        public IActionResult GetAll()
        {
            List<AttendanceRecord> records = new();

            using var conn = GetConnection();
            using var cmd = new SqlCommand("GetAllAttendanceRecords", conn)
            {
                CommandType = CommandType.StoredProcedure
            };

            conn.Open();
            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                records.Add(new AttendanceRecord
                {
                    AttendanceRecordID = reader["AttendanceRecordID"].ToString()!,
                    AttendanceDate = Convert.ToDateTime(reader["AttendanceDate"]),
                    InTime = TimeOnly.Parse(reader["InTime"].ToString()!),
                    OutTime = TimeOnly.Parse(reader["OutTime"].ToString()!),
                    OTStart = TimeOnly.Parse(reader["OTStart"].ToString()!),
                    OTEnd = TimeOnly.Parse(reader["OTEnd"].ToString()!),
                    TotalRegularHours = TimeSpan.Parse(reader["TotalRegularHours"].ToString()!),
                    TotalOvertimeHours = TimeSpan.Parse(reader["TotalOvertimeHours"].ToString()!),
                    DayType = reader["DayType"].ToString()!,
                    AttendanceConfigurationID = reader["AttendanceConfigurationID"].ToString()!,
                    //EmployeeID = reader["EmployeeID"].ToString()!,
                    AttendanceStatusID = reader["AttendanceStatusID"].ToString()!
                });
            }

            return Ok(records);
        }

        // GET By ID
        [HttpGet("get/{id}")]
        public IActionResult GetById(string id)
        {
            AttendanceRecord? record = null;

            using var conn = GetConnection();
            using var cmd = new SqlCommand("GetAttendanceRecordByID", conn)
            {
                CommandType = CommandType.StoredProcedure
            };

            cmd.Parameters.AddWithValue("@AttendanceRecordID", id);
            conn.Open();

            using var reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                record = new AttendanceRecord
                {
                    AttendanceRecordID = reader["AttendanceRecordID"].ToString()!,
                    AttendanceDate = Convert.ToDateTime(reader["AttendanceDate"]),
                    InTime = TimeOnly.Parse(reader["InTime"].ToString()!),
                    OutTime = TimeOnly.Parse(reader["OutTime"].ToString()!),
                    OTStart = TimeOnly.Parse(reader["OTStart"].ToString()!),
                    OTEnd = TimeOnly.Parse(reader["OTEnd"].ToString()!),
                    TotalRegularHours = TimeSpan.Parse(reader["TotalRegularHours"].ToString()!),
                    TotalOvertimeHours = TimeSpan.Parse(reader["TotalOvertimeHours"].ToString()!),
                    DayType = reader["DayType"].ToString()!,
                    AttendanceConfigurationID = reader["AttendanceConfigurationID"].ToString()!,
                    //EmployeeID = reader["EmployeeID"].ToString()!,
                    AttendanceStatusID = reader["AttendanceStatusID"].ToString()!
                };
            }

            if (record == null)
                return NotFound("Record not found.");

            return Ok(record);
        }

        // INSERT
        [HttpPost("insert")]
        public IActionResult Insert(AttendanceRecord record)
        {
            using var conn = GetConnection();
            using var cmd = new SqlCommand("InsertAttendanceRecord", conn)
            {
                CommandType = CommandType.StoredProcedure
            };

            cmd.Parameters.AddWithValue("@AttendanceRecordID", record.AttendanceRecordID);
            cmd.Parameters.AddWithValue("@AttendanceDate", record.AttendanceDate);
            cmd.Parameters.AddWithValue("@InTime", record.InTime);
            cmd.Parameters.AddWithValue("@OutTime", record.OutTime);
            cmd.Parameters.AddWithValue("@OTStart", record.OTStart);
            cmd.Parameters.AddWithValue("@OTEnd", record.OTEnd);
            cmd.Parameters.AddWithValue("@TotalRegularHours", record.TotalRegularHours);
            cmd.Parameters.AddWithValue("@TotalOvertimeHours", record.TotalOvertimeHours);
            cmd.Parameters.AddWithValue("@DayType", record.DayType);
            cmd.Parameters.AddWithValue("@AttendanceConfigurationID", record.AttendanceConfigurationID);
            //cmd.Parameters.AddWithValue("@EmployeeID", record.EmployeeID);
            cmd.Parameters.AddWithValue("@AttendanceStatusID", record.AttendanceStatusID);

            conn.Open();
            cmd.ExecuteNonQuery();

            return Ok("Insert successful.");
        }

        // UPDATE
        [HttpPut("update")]
        public IActionResult Update(AttendanceRecord record)
        {
            using var conn = GetConnection();
            using var cmd = new SqlCommand("UpdateAttendanceRecord", conn)
            {
                CommandType = CommandType.StoredProcedure
            };

            cmd.Parameters.AddWithValue("@AttendanceRecordID", record.AttendanceRecordID);
            cmd.Parameters.AddWithValue("@AttendanceDate", record.AttendanceDate);
            cmd.Parameters.AddWithValue("@InTime", record.InTime);
            cmd.Parameters.AddWithValue("@OutTime", record.OutTime);
            cmd.Parameters.AddWithValue("@OTStart", record.OTStart);
            cmd.Parameters.AddWithValue("@OTEnd", record.OTEnd);
            cmd.Parameters.AddWithValue("@TotalRegularHours", record.TotalRegularHours);
            cmd.Parameters.AddWithValue("@TotalOvertimeHours", record.TotalOvertimeHours);
            cmd.Parameters.AddWithValue("@DayType", record.DayType);
            cmd.Parameters.AddWithValue("@AttendanceConfigurationID", record.AttendanceConfigurationID);
            //cmd.Parameters.AddWithValue("@EmployeeID", record.EmployeeID);
            cmd.Parameters.AddWithValue("@AttendanceStatusID", record.AttendanceStatusID);

            conn.Open();
            cmd.ExecuteNonQuery();

            return Ok("Update successful.");
        }

        // DELETE
        [HttpDelete("delete/{id}")]
        public IActionResult Delete(string id)
        {
            using var conn = GetConnection();
            using var cmd = new SqlCommand("DeleteAttendanceRecord", conn)
            {
                CommandType = CommandType.StoredProcedure
            };

            cmd.Parameters.AddWithValue("@AttendanceRecordID", id);

            conn.Open();
            cmd.ExecuteNonQuery();

            return Ok("Delete successful.");
        }
    }
}
