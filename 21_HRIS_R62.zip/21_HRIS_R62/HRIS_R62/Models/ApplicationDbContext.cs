﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using static System.Collections.Specialized.BitVector32;

namespace HRIS_R62.Models
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }
        public DbSet<AttendanceBonus> AttendanceBonus { get; set; }
        public DbSet<AttendanceRecord> AttendanceRecords { get; set; }
        public DbSet<BonusRecord> BonusRecords { get; set; }
        public DbSet<CareerHistory> CareerHistories { get; set; }
        public DbSet<ChildrenInformation> ChildrenInformations { get; set; }
        public DbSet<Company> Companies { get; set; }
        public DbSet<ContactPersonInformation> ContactPersonInformations { get; set; }
        public DbSet<DateWiseOfficeTime> DateWiseOfficeTimes { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<Designation> Designations { get; set; }
        public DbSet<DisciplinaryAction> DisciplinaryActions { get; set; }
        public DbSet<Division> Divisions { get; set; }
        public DbSet<EarlyLeaveInformation> EarlyLeaveInformation { get; set; }
        public DbSet<EmployeeBenefits> EmployeeBenefits { get; set; }
        public DbSet<EmployeeComplaint> EmployeeComplaints { get; set; }
        public DbSet<EmployeeInformation> EmployeeInformations { get; set; }
        public DbSet<OverTime> OverTimes { get; set; }
        public DbSet<EmployeeSkill> EmployeeSkills { get; set; }
        public DbSet<EmployeeTax> EmployeeTaxes { get; set; }
        public DbSet<EmploymentType> EmploymentTypes { get; set; }
        public DbSet<FestivalBonus> FestivalBonuses { get; set; }
        public DbSet<FoodCharge> FoodCharges { get; set; }
        public DbSet<Grade> Grades { get; set; }
        public DbSet<HoliDayBillRate> HoliDayBillRates { get; set; }
        public DbSet<HoliDayEntitledEmployee> HoliDayEntitledEmployees { get; set; }
        public DbSet<HoliDayInformation> HoliDayInformations { get; set; }
        public DbSet<JobLeft> JobLefts { get; set; }
        public DbSet<LateApproval> LateApprovals { get; set; }
        public DbSet<LeaveApproval> LeaveApprovals { get; set; }
        public DbSet<LeaveEncashment> LeaveEncashments { get; set; }
        public DbSet<LeaveEncashmentRate> LeaveEncashmentRates { get; set; }
        public DbSet<LeaveRecord> LeaveRecords { get; set; }
        public DbSet<LineInformation> LineInformations { get; set; }
        public DbSet<ManualAttendance> ManualAttendances { get; set; }
        public DbSet<NightAllowance> NightAllowances { get; set; }
        public DbSet<NightAllowanceTime> NightAllowanceTimes { get; set; }
        public DbSet<NomineeInformation> NomineeInformations { get; set; }
        public DbSet<ProximityRecord> ProximityRecords { get; set; }
        public DbSet<SalaryDeduction> SalaryDeductions { get; set; }
        public DbSet<SalaryEntry> SalaryEntrys { get; set; }
        public DbSet<SalaryGrade> SalaryGrades { get; set; }
        public DbSet<SalaryProcess> SalaryProcesss { get; set; }
        public DbSet<SalaryRecord> SalaryRecords { get; set; }
        public DbSet<Sections> Sections { get; set; }
        public DbSet<ShiftEmployee> ShiftEmployees { get; set; }
        public DbSet<SpecialEmployee> SpecialEmployees { get; set; }
        public DbSet<SpouseInformation> SpouseInformations { get; set; }
        public DbSet<Suspend> Suspends { get; set; }
        public DbSet<TaxAmount> TaxAmounts { get; set; }
        public DbSet<TaxExempted> TaxExempteds { get; set; }
        public DbSet<TaxRule> TaxRules { get; set; }
        public DbSet<TiffinAllowanceRate> TiffinAllowanceRates { get; set; }
        public DbSet<TiffinAllowanceTime> TiffinAllowanceTimes { get; set; }
        public DbSet<Unit> Units { get; set; }
        public DbSet<MaternityBill> MaternityBills { get; set; }
        public DbSet<MaternityConfiguration> MaternityConfigurations { get; set; }
        public DbSet<ShiftTime> ShiftTimes { get; set; }
        public DbSet<AttendanceConfiguration> AttendanceConfigurations { get; set; }
        public DbSet<AttendanceStatus> AttendanceStatuss { get; set; }
        public DbSet<Building> Buildings { get; set; }
        public DbSet<LogFile> LogFiles { get; set; }

        public async Task InsertHolidayBillRateAsync(HoliDayBillRate holiDayBillRate)
        {
            var parameters = new[]
            {
        new SqlParameter("@HoliDayBillRateID", holiDayBillRate.HoliDayBillRateID),
        new SqlParameter("@SerialNumber", holiDayBillRate.SerialNumber),
        new SqlParameter("@SalaryMinimum", holiDayBillRate.SalaryMinimum),
        new SqlParameter("@SalaryMaximum", holiDayBillRate.SalaryMaximum),
        new SqlParameter("@HoliDayBillRateValue", holiDayBillRate.HoliDayBillRateValue),
        new SqlParameter("@EmployeeID", holiDayBillRate.EmployeeID)
            };

            await Database.ExecuteSqlRawAsync(
                "EXEC sp_InsertHoliDayBillRate @HoliDayBillRateID, @SerialNumber, @SalaryMinimum, @SalaryMaximum, @HoliDayBillRateValue, @EmployeeID",
                parameters
            );
        }

        public async Task InsertHolidayEntitledEmployeeAsync(HoliDayEntitledEmployee employee)
        {
            var parameters = new[]
            {
        new SqlParameter("@HoliDayEntitledEmployeeID", employee.HoliDayEntitledEmployeeID),
        new SqlParameter("@AttendanceDate", employee.AttendanceDate),
        new SqlParameter("@AttendanceStatus", employee.AttendanceStatus ?? (object)DBNull.Value),
        new SqlParameter("@LocalAreaClerance", employee.LocalAreaClerance ?? (object)DBNull.Value),
        new SqlParameter("@LocalAreaRemarks", employee.LocalAreaRemarks ?? (object)DBNull.Value),
        new SqlParameter("@ApprovedDate", employee.ApprovedDate),
        new SqlParameter("@EntryUser", employee.EntryUser ?? (object)DBNull.Value),
        new SqlParameter("@EmployeeID", employee.EmployeeID)
    };

            await Database.ExecuteSqlRawAsync(
                "EXEC usp_InsertHoliDayEntitledEmployee @HoliDayEntitledEmployeeID, @AttendanceDate, @AttendanceStatus, @LocalAreaClerance, @LocalAreaRemarks, @ApprovedDate, @EntryUser, @EmployeeID",
                parameters
            );
        }

        public async Task InsertHolidayainformationAsync(HoliDayInformation holiDayInformation)
        {
            var parameters = new[]
            {
        new SqlParameter("@HoliDayInformationID", holiDayInformation.HoliDayInformationID ?? (object)DBNull.Value),
        new SqlParameter("@FromDate", holiDayInformation.FromDate),
        new SqlParameter("@EndDate", holiDayInformation.EndDate),
        new SqlParameter("@EventType", holiDayInformation.EventType ?? (object)DBNull.Value),
        new SqlParameter("@EventName", holiDayInformation.EventName ?? (object)DBNull.Value),
        new SqlParameter("@Remarks", holiDayInformation.Remarks ?? (object)DBNull.Value),
        new SqlParameter("@EntryUser", holiDayInformation.EntryUser ?? (object)DBNull.Value),
        new SqlParameter("@EmployeeID", holiDayInformation.EmployeeID ?? (object)DBNull.Value)
    };

            await Database.ExecuteSqlRawAsync(
                "EXEC usp_InsertHoliDayInformation @HoliDayInformationID, @FromDate, @EndDate, @EventType, @EventName, @Remarks, @EntryUser, @EmployeeID",
                parameters
            );
        }

        public async Task InsertEmployeeBenefitAsync(EmployeeBenefits benefit)
        {
            var parameters = new[]
            {
        new SqlParameter("@BenefitID", benefit.BenefitID),
        new SqlParameter("@EmployeeID", benefit.EmployeeID ?? (object)DBNull.Value),
        new SqlParameter("@BenefitDate", benefit.BenefitDate ?? (object)DBNull.Value),
        new SqlParameter("@BenefitAmount", benefit.BenefitAmount),
        new SqlParameter("@BenefitType", benefit.BenefitType ?? (object)DBNull.Value),
        new SqlParameter("@BenefitActivationDate", benefit.BenefitActivationDate ?? (object)DBNull.Value),
        new SqlParameter("@PreviousNetSalary", benefit.PreviousNetSalary),
        new SqlParameter("@NewNetSalary", benefit.NewNetSalary),
        new SqlParameter("@SalaryStepID", benefit.SalaryStepID ?? (object)DBNull.Value),
        new SqlParameter("@GradeID", benefit.GradeID ?? (object)DBNull.Value),
        new SqlParameter("@GrossSalary", benefit.GrossSalary),
        new SqlParameter("@BasicSalary", benefit.BasicSalary),
        new SqlParameter("@HouseRent", benefit.HouseRent),
        new SqlParameter("@MedicalAllowance", benefit.MedicalAllowance),
        new SqlParameter("@ConveyanceAllowance", benefit.ConveyanceAllowance),
        new SqlParameter("@LunchAllowance", benefit.LunchAllowance),
        new SqlParameter("@OtherAllowance", benefit.OtherAllowance),
        new SqlParameter("@SalaryRecordID", benefit.SalaryRecordID ?? (object)DBNull.Value),
        new SqlParameter("@CashIncentive", benefit.CashIncentive),
        new SqlParameter("@LocalAreaClerance", benefit.LocalAreaClerance ?? (object)DBNull.Value),
        new SqlParameter("@LocalAreaRemarks", benefit.LocalAreaRemarks ?? (object)DBNull.Value),
        new SqlParameter("@ApprovalDate", benefit.ApprovalDate ?? (object)DBNull.Value),
        new SqlParameter("@EntryUser", benefit.EntryUser ?? (object)DBNull.Value),
        new SqlParameter("@SalaryGradeID", benefit.SalaryGradeID ?? (object)DBNull.Value)
    };

            await Database.ExecuteSqlRawAsync(
                "EXEC usp_InsertEmployeeBenefits @BenefitID, @EmployeeID, @BenefitDate, @BenefitAmount, @BenefitType, @BenefitActivationDate, " +
                "@PreviousNetSalary, @NewNetSalary, @SalaryStepID, @GradeID, @GrossSalary, @BasicSalary, @HouseRent, @MedicalAllowance, " +
                "@ConveyanceAllowance, @LunchAllowance, @OtherAllowance, @SalaryRecordID, @CashIncentive, @LocalAreaClerance, " +
                "@LocalAreaRemarks, @ApprovalDate, @EntryUser, @SalaryGradeID",
                parameters
            );
        }
    }
}
